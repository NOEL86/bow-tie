import React from "react";
import "./Loader.css";
const Loader = props => <div className="lds-hourglass"></div>;
export default Loader;
